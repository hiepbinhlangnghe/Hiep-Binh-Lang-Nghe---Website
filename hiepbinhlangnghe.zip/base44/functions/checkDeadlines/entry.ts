import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const DEPARTMENT_NAMES = {
  kinh_te_ha_tang: 'Phòng Kinh tế Hạ tầng',
  van_hoa_xa_hoi: 'Phòng Văn hóa Xã hội',
  cong_an: 'Công an phường'
};

Deno.serve(async (req) => {
  try {
    // Dùng service role vì automation chạy không có user session
    const base44 = createClientFromRequest(req);

    const [issues, allUsers] = await Promise.all([
      base44.asServiceRole.entities.Issue.list('-created_date', 500),
      base44.asServiceRole.entities.User.list()
    ]);

    const now = new Date();
    let reminders = 0;

    for (const issue of issues) {
      // Bỏ qua hồ sơ đã xử lý xong hoặc đã quá hạn
      if (['RESOLVED', 'NOTIFIED', 'OVERDUE'].includes(issue.status)) continue;

      const createdDate = new Date(issue.created_date);
      const hoursSinceCreated = (now - createdDate) / (1000 * 60 * 60);

      // NEW quá 24 giờ chưa tiếp nhận → đánh dấu OVERDUE, nhắc nhở tổ tiếp nhận
      if (issue.status === 'NEW' && hoursSinceCreated > 24) {
        await base44.asServiceRole.entities.Issue.update(issue.id, { status: 'OVERDUE' });

        // Gửi email cho tất cả receiving_staff
        const receivingStaff = allUsers.filter(u => (u.role === 'receiving_staff' || u.role === 'admin') && u.email);
        await Promise.all(receivingStaff.map(u =>
          base44.asServiceRole.integrations.Core.SendEmail({
            to: u.email,
            subject: `[QUÁ HẠN] Hồ sơ ${issue.tracking_code} chưa được tiếp nhận`,
            body: `
<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;">
  <div style="background:#dc2626;padding:16px 24px;color:white;">
    <h2 style="margin:0;font-size:16px;">⚠️ Hồ sơ QUÁ HẠN tiếp nhận</h2>
  </div>
  <div style="padding:20px 24px;">
    <p>Hồ sơ <strong>${issue.tracking_code}</strong> đã quá 24 giờ mà chưa được tiếp nhận.</p>
    <table style="border-collapse:collapse;width:100%;margin:12px 0;">
      <tr><td style="padding:8px;border:1px solid #e5e7eb;color:#6b7280;">Tiêu đề</td><td style="padding:8px;border:1px solid #e5e7eb;">${issue.title}</td></tr>
      <tr><td style="padding:8px;border:1px solid #e5e7eb;color:#6b7280;">Lĩnh vực</td><td style="padding:8px;border:1px solid #e5e7eb;">${issue.category}</td></tr>
      <tr><td style="padding:8px;border:1px solid #e5e7eb;color:#6b7280;">Ngày gửi</td><td style="padding:8px;border:1px solid #e5e7eb;">${new Date(issue.created_date).toLocaleString('vi-VN')}</td></tr>
    </table>
    <p style="color:#dc2626;font-weight:bold;">Vui lòng tiếp nhận và xử lý ngay.</p>
  </div>
</div>`
          }).catch(e => console.error('Email error:', e.message))
        ));

        reminders++;
        continue;
      }

      // FORWARDED/IN_PROGRESS quá 72 giờ → đánh dấu OVERDUE, nhắc bộ phận chịu trách nhiệm
      if (['FORWARDED', 'IN_PROGRESS'].includes(issue.status) && issue.forwarded_at) {
        const forwardedDate = new Date(issue.forwarded_at);
        const hoursSinceForwarded = (now - forwardedDate) / (1000 * 60 * 60);

        if (hoursSinceForwarded > 72) {
          await base44.asServiceRole.entities.Issue.update(issue.id, { status: 'OVERDUE' });

          const dept = issue.assigned_department;
          const deptName = DEPARTMENT_NAMES[dept] || dept;

          // Gửi email cho nhân sự phòng ban đó + admin
          const deptUsers = allUsers.filter(u =>
            (u.department === dept || u.role === 'admin') && u.email
          );

          await Promise.all(deptUsers.map(u =>
            base44.asServiceRole.integrations.Core.SendEmail({
              to: u.email,
              subject: `[QUÁ HẠN] Hồ sơ ${issue.tracking_code} cần xử lý gấp`,
              body: `
<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;">
  <div style="background:#dc2626;padding:16px 24px;color:white;">
    <h2 style="margin:0;font-size:16px;">⚠️ Hồ sơ QUÁ HẠN xử lý — ${deptName}</h2>
  </div>
  <div style="padding:20px 24px;">
    <p>Kính gửi <strong>${deptName}</strong>,</p>
    <p>Hồ sơ sau đây đã quá <strong>72 giờ</strong> kể từ khi chuyển tiếp mà chưa hoàn thành:</p>
    <table style="border-collapse:collapse;width:100%;margin:12px 0;">
      <tr><td style="padding:8px;border:1px solid #e5e7eb;color:#6b7280;">Mã hồ sơ</td><td style="padding:8px;border:1px solid #e5e7eb;font-weight:bold;">${issue.tracking_code}</td></tr>
      <tr><td style="padding:8px;border:1px solid #e5e7eb;color:#6b7280;">Tiêu đề</td><td style="padding:8px;border:1px solid #e5e7eb;">${issue.title}</td></tr>
      <tr><td style="padding:8px;border:1px solid #e5e7eb;color:#6b7280;">Ngày chuyển</td><td style="padding:8px;border:1px solid #e5e7eb;">${new Date(issue.forwarded_at).toLocaleString('vi-VN')}</td></tr>
      ${issue.issue_address ? `<tr><td style="padding:8px;border:1px solid #e5e7eb;color:#6b7280;">Địa chỉ</td><td style="padding:8px;border:1px solid #e5e7eb;">${issue.issue_address}</td></tr>` : ''}
    </table>
    <p style="color:#dc2626;font-weight:bold;">Yêu cầu hoàn thành và cập nhật kết quả ngay trong hôm nay.</p>
  </div>
</div>`
            }).catch(e => console.error('Email error:', e.message))
          ));

          reminders++;
        }
      }
    }

    return Response.json({ success: true, reminders_sent: reminders });
  } catch (error) {
    console.error('Deadline check error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});