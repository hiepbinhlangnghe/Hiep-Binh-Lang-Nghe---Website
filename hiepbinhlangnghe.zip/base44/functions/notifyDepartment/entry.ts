import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const DEPARTMENT_NAMES = {
  kinh_te_ha_tang: 'Phòng Kinh tế Hạ tầng',
  van_hoa_xa_hoi: 'Phòng Văn hóa Xã hội',
  cong_an: 'Công an phường'
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { issue_id } = await req.json();
    if (!issue_id) return Response.json({ error: 'Missing issue_id' }, { status: 400 });

    const [issues, allUsers] = await Promise.all([
      base44.asServiceRole.entities.Issue.filter({ id: issue_id }),
      base44.asServiceRole.entities.User.list()
    ]);

    const issue = issues[0];
    if (!issue) return Response.json({ error: 'Issue not found' }, { status: 404 });

    const dept = issue.assigned_department;
    const deptName = DEPARTMENT_NAMES[dept] || dept;

    // Lấy email của tất cả nhân sự thuộc phòng ban
    const deptUsers = allUsers.filter(u => u.department === dept && u.email);
    if (!deptUsers.length) return Response.json({ error: 'No users found for department: ' + dept }, { status: 400 });

    // Tạo resolve token
    const token = btoa(`${issue.id}:${issue.tracking_code}`);
    const resolveUrl = `${req.headers.get('origin') || 'https://preview-sandbox--69f58e8c299b3c5e4bfd8065.base44.app'}/resolve/${token}`;

    const emailBody = `
<div style="font-family: Arial, sans-serif; max-width: 700px; margin: 0 auto; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
  <div style="background: #1e3a5f; padding: 20px 30px; color: white;">
    <h2 style="margin:0; font-size:18px;">📋 Yêu cầu xử lý phản ánh mới</h2>
    <p style="margin:4px 0 0; opacity:0.8; font-size:13px;">Hệ thống Hiệp Bình Lắng Nghe</p>
  </div>

  <div style="padding: 24px 30px; background: #f9fafb;">
    <p style="margin: 0 0 16px; color:#374151;">Kính gửi <strong>${deptName}</strong>,</p>
    <p style="margin: 0 0 20px; color:#374151;">Bộ phận nhận được phản ánh cần xử lý với thông tin như sau:</p>

    <table style="width:100%; border-collapse:collapse; background:white; border-radius:8px; overflow:hidden; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
      <tr style="background:#f3f4f6;"><td colspan="2" style="padding:12px 16px; font-weight:bold; color:#111827; font-size:14px;">Mã hồ sơ: ${issue.tracking_code}</td></tr>
      <tr><td style="padding:10px 16px; color:#6b7280; width:140px; border-top:1px solid #f3f4f6;">Tiêu đề</td><td style="padding:10px 16px; color:#111827; border-top:1px solid #f3f4f6;">${issue.title}</td></tr>
      ${issue.issue_address ? `<tr><td style="padding:10px 16px; color:#6b7280; border-top:1px solid #f3f4f6;">Địa chỉ sự việc</td><td style="padding:10px 16px; color:#111827; border-top:1px solid #f3f4f6;">${issue.issue_address}</td></tr>` : ''}
      <tr><td style="padding:10px 16px; color:#6b7280; border-top:1px solid #f3f4f6; vertical-align:top;">Nội dung</td><td style="padding:10px 16px; color:#111827; border-top:1px solid #f3f4f6; white-space:pre-wrap;">${issue.description}</td></tr>
    </table>

    <div style="margin-top:24px; text-align:center;">
      <a href="${resolveUrl}" style="display:inline-block; background:#16a34a; color:white; text-decoration:none; padding:14px 32px; border-radius:6px; font-size:16px; font-weight:bold;">
        ✅ Báo cáo hoàn thành xử lý
      </a>
      <p style="margin:12px 0 0; color:#6b7280; font-size:12px;">Nhấn nút trên để điền kết quả xử lý và đính kèm hình ảnh minh chứng</p>
    </div>
  </div>

  <div style="padding:16px 30px; background:#f3f4f6; border-top:1px solid #e5e7eb; text-align:center; color:#9ca3af; font-size:12px;">
    © ${new Date().getFullYear()} UBND Phường Hiệp Bình — Hệ thống Hiệp Bình Lắng Nghe
  </div>
</div>`;

    await Promise.all(deptUsers.map(u =>
      base44.asServiceRole.integrations.Core.SendEmail({
        to: u.email,
        subject: `[Hiệp Bình Lắng Nghe] Phản ánh cần xử lý: ${issue.tracking_code} — ${issue.title}`,
        body: emailBody
      })
    ));

    return Response.json({ success: true, sent_to: deptUsers.map(u => u.email) });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});