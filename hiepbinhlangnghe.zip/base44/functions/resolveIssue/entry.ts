import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { token, resolution_note, result_attachments } = await req.json();

    if (!token) return Response.json({ error: 'Missing token' }, { status: 400 });
    if (!resolution_note?.trim()) return Response.json({ error: 'Vui lòng nhập ghi chú kết quả' }, { status: 400 });
    if (!result_attachments?.length) return Response.json({ error: 'Vui lòng đính kèm ít nhất 1 hình ảnh/tài liệu' }, { status: 400 });

    // Decode token
    let issueId, trackingCode;
    try {
      const decoded = atob(token);
      [issueId, trackingCode] = decoded.split(':');
    } catch {
      return Response.json({ error: 'Token không hợp lệ' }, { status: 400 });
    }

    const issues = await base44.asServiceRole.entities.Issue.filter({ id: issueId });
    const issue = issues[0];
    if (!issue) return Response.json({ error: 'Không tìm thấy hồ sơ' }, { status: 404 });

    // Verify tracking code matches
    if (issue.tracking_code !== trackingCode) {
      return Response.json({ error: 'Token không hợp lệ' }, { status: 400 });
    }

    if (issue.status === 'RESOLVED') {
      return Response.json({ error: 'Hồ sơ này đã được xử lý rồi' }, { status: 400 });
    }

    await base44.asServiceRole.entities.Issue.update(issueId, {
      status: 'RESOLVED',
      resolved_at: new Date().toISOString(),
      resolution_note: resolution_note.trim(),
      result_attachments: result_attachments
    });

    return Response.json({ success: true, tracking_code: trackingCode });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});