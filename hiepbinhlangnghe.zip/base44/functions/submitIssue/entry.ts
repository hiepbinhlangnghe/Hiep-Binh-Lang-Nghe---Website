import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    const { full_name, phone, email, citizen_address, category, subcategory, title, description, issue_address, maps_link, attachments } = body;

    // Validate bắt buộc (server-side)
    if (!full_name || !phone || !email || !category || !subcategory || !title || !description || !issue_address) {
      return Response.json({ error: 'Vui lòng điền đầy đủ thông tin bắt buộc' }, { status: 400 });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return Response.json({ error: 'Email không hợp lệ' }, { status: 400 });
    }

    const phoneRegex = /^(0|\+84)[0-9]{9,10}$/;
    if (!phoneRegex.test(phone.replace(/\s/g, ''))) {
      return Response.json({ error: 'Số điện thoại không hợp lệ' }, { status: 400 });
    }

    const validCategories = ['kinh_te_do_thi', 'van_hoa_xa_hoi', 'an_ninh_trat_tu'];
    if (!validCategories.includes(category)) {
      return Response.json({ error: 'Lĩnh vực không hợp lệ' }, { status: 400 });
    }

    // Dùng asServiceRole vì đây là public endpoint (không cần user đăng nhập)
    const citizen = await base44.asServiceRole.entities.CitizenInfo.create({
      full_name: full_name.trim(),
      phone: phone.trim(),
      email: email.trim().toLowerCase(),
      citizen_address: citizen_address?.trim() || ''
    });

    // Generate tracking code
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
    const random = Math.floor(1000 + Math.random() * 9000);
    const tracking_code = `HB-${dateStr}-${random}`;

    // Tạo Issue liên kết với CitizenInfo
    await base44.asServiceRole.entities.Issue.create({
      tracking_code,
      citizen_id: citizen.id,
      category,
      subcategory: subcategory.trim(),
      title: title.trim(),
      description: description.trim(),
      issue_address: issue_address.trim(),
      maps_link: maps_link?.trim() || '',
      attachments: attachments || [],
      status: 'NEW'
    });

    // Gửi email xác nhận cho công dân
    try {
      const categoryLabels = {
        'kinh_te_do_thi': 'Kinh tế - Đô thị',
        'van_hoa_xa_hoi': 'Văn hóa, Xã hội',
        'an_ninh_trat_tu': 'An ninh trật tự'
      };

      await base44.asServiceRole.integrations.Core.SendEmail({
        from_name: 'Hiệp Bình Lắng Nghe',
        to: email,
        subject: `[Hiệp Bình Lắng Nghe] Xác nhận tiếp nhận phản ánh - ${tracking_code}`,
        body: `
<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;">
  <div style="background:#1e3a5f;padding:20px 30px;color:white;">
    <h2 style="margin:0;font-size:18px;">✅ Phản ánh đã được ghi nhận</h2>
    <p style="margin:4px 0 0;opacity:0.8;font-size:13px;">Hệ thống Hiệp Bình Lắng Nghe</p>
  </div>
  <div style="padding:24px 30px;">
    <p>Xin chào <strong>${full_name}</strong>,</p>
    <p>Phản ánh của bạn đã được ghi nhận thành công với thông tin sau:</p>
    <table style="border-collapse:collapse;width:100%;margin:16px 0;">
      <tr><td style="padding:8px 12px;border:1px solid #e5e7eb;font-weight:bold;background:#f9fafb;width:130px;">Mã hồ sơ</td><td style="padding:8px 12px;border:1px solid #e5e7eb;color:#1a56db;font-weight:bold;">${tracking_code}</td></tr>
      <tr><td style="padding:8px 12px;border:1px solid #e5e7eb;font-weight:bold;background:#f9fafb;">Lĩnh vực</td><td style="padding:8px 12px;border:1px solid #e5e7eb;">${categoryLabels[category] || category}</td></tr>
      <tr><td style="padding:8px 12px;border:1px solid #e5e7eb;font-weight:bold;background:#f9fafb;">Tiêu đề</td><td style="padding:8px 12px;border:1px solid #e5e7eb;">${title}</td></tr>
      <tr><td style="padding:8px 12px;border:1px solid #e5e7eb;font-weight:bold;background:#f9fafb;">Địa chỉ SV</td><td style="padding:8px 12px;border:1px solid #e5e7eb;">${issue_address}</td></tr>
    </table>
    <p>Bạn có thể dùng mã hồ sơ để theo dõi tình trạng xử lý trên hệ thống.</p>
    <p style="margin-top:20px;color:#6b7280;font-size:12px;">Trân trọng,<br/>UBND Phường Hiệp Bình — Hệ thống Hiệp Bình Lắng Nghe</p>
  </div>
</div>`
      });
    } catch (emailErr) {
      console.error('Failed to send citizen email:', emailErr.message);
    }

    return Response.json({
      success: true,
      tracking_code,
      message: 'Phản ánh đã được gửi thành công'
    });

  } catch (error) {
    console.error('Submit error:', error.message);
    return Response.json({ error: 'Có lỗi xảy ra, vui lòng thử lại sau' }, { status: 500 });
  }
});