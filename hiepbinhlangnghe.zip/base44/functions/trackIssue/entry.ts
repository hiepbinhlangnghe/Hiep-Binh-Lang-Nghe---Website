import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { tracking_code } = await req.json();

    if (!tracking_code) {
      return Response.json({ error: 'Vui lòng nhập mã hồ sơ' }, { status: 400 });
    }

    const issues = await base44.asServiceRole.entities.Issue.filter({ tracking_code });
    if (!issues.length) {
      return Response.json({ error: 'Không tìm thấy hồ sơ với mã này' }, { status: 404 });
    }

    const issue = issues[0];

    // Lấy thông tin công dân
    let citizen = null;
    if (issue.citizen_id) {
      const citizens = await base44.asServiceRole.entities.CitizenInfo.filter({ id: issue.citizen_id });
      citizen = citizens[0] || null;
    }

    // Trả về thông tin không nhạy cảm cho công dân tra cứu
    return Response.json({
      tracking_code: issue.tracking_code,
      title: issue.title,
      category: issue.category,
      subcategory: issue.subcategory,
      status: issue.status,
      issue_address: issue.issue_address,
      assigned_department: issue.assigned_department,
      created_date: issue.created_date,
      received_at: issue.received_at,
      forwarded_at: issue.forwarded_at,
      resolved_at: issue.resolved_at,
      resolution_note: issue.resolution_note,
      result_attachments: issue.result_attachments,
      // Chỉ trả về tên, không trả email/phone
      full_name: citizen?.full_name || ''
    });

  } catch (error) {
    console.error('Track error:', error.message);
    return Response.json({ error: 'Có lỗi xảy ra' }, { status: 500 });
  }
});