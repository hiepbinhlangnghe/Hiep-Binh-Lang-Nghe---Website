import React, { useState, useCallback, useRef } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import { MapPin, X, Search, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix leaflet default marker icon
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

// Tâm phường Hiệp Bình Chánh, TP Thủ Đức
const DEFAULT_CENTER = [10.8466, 106.7417];
const DEFAULT_ZOOM = 15;

function MapClickHandler({ onLocationSelect }) {
  useMapEvents({
    click(e) {
      onLocationSelect(e.latlng.lat, e.latlng.lng);
    }
  });
  return null;
}

export default function LocationPicker({ value, mapsLink, onChange, onMapsLinkChange }) {
  const [showMap, setShowMap] = useState(false);
  const [marker, setMarker] = useState(null);
  const [searching, setSearching] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const mapRef = useRef(null);

  const handleLocationSelect = useCallback(async (lat, lng) => {
    setMarker({ lat, lng });
    const mapsUrl = `https://www.google.com/maps?q=${lat},${lng}`;
    onMapsLinkChange(mapsUrl);

    // Reverse geocode để lấy địa chỉ
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&accept-language=vi`
      );
      const data = await res.json();
      if (data.display_name) {
        onChange(data.display_name);
      }
    } catch {
      onChange(`${lat.toFixed(6)}, ${lng.toFixed(6)}`);
    }
  }, [onChange, onMapsLinkChange]);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setSearching(true);
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(searchQuery + ', Hiệp Bình, Thủ Đức, Hồ Chí Minh')}&format=json&limit=1&accept-language=vi`
      );
      const data = await res.json();
      if (data.length > 0) {
        const { lat, lon, display_name } = data[0];
        const latNum = parseFloat(lat);
        const lngNum = parseFloat(lon);
        setMarker({ lat: latNum, lng: lngNum });
        onChange(display_name);
        onMapsLinkChange(`https://www.google.com/maps?q=${latNum},${lngNum}`);
        if (mapRef.current) {
          mapRef.current.flyTo([latNum, lngNum], 17);
        }
      } else {
        alert('Không tìm thấy địa chỉ, vui lòng thử lại hoặc chọn trực tiếp trên bản đồ.');
      }
    } catch {
      alert('Không thể tìm kiếm, vui lòng chọn trực tiếp trên bản đồ.');
    } finally {
      setSearching(false);
    }
  };

  return (
    <div className="space-y-2">
      {/* Text input */}
      <div className="flex gap-2">
        <Input
          placeholder="Nhập địa chỉ cụ thể nơi xảy ra vấn đề"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="rounded-none border-0 border-b border-gray-200 focus-visible:ring-0 focus-visible:border-gray-500 px-0 flex-1"
        />
        <button
          type="button"
          onClick={() => setShowMap(!showMap)}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border rounded transition-colors whitespace-nowrap ${
            showMap
              ? 'bg-primary text-white border-primary'
              : 'border-gray-300 text-gray-600 hover:bg-gray-50'
          }`}
        >
          <MapPin className="w-3.5 h-3.5" />
          {marker ? 'Đã chọn' : 'Chọn trên bản đồ'}
        </button>
      </div>

      {/* Map panel */}
      {showMap && (
        <div className="border border-gray-200 rounded-lg overflow-hidden">
          {/* Search bar on map */}
          <div className="flex gap-2 p-2 bg-gray-50 border-b border-gray-200">
            <Input
              placeholder="Tìm kiếm địa chỉ..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleSearch())}
              className="h-8 text-sm"
            />
            <button
              type="button"
              onClick={handleSearch}
              disabled={searching}
              className="flex items-center gap-1 px-3 py-1 bg-primary text-white text-xs rounded hover:bg-primary/90 disabled:opacity-60"
            >
              {searching ? <Loader2 className="w-3 h-3 animate-spin" /> : <Search className="w-3 h-3" />}
              Tìm
            </button>
          </div>

          <div className="relative">
            <MapContainer
              center={DEFAULT_CENTER}
              zoom={DEFAULT_ZOOM}
              style={{ height: '320px', width: '100%' }}
              ref={mapRef}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <MapClickHandler onLocationSelect={handleLocationSelect} />
              {marker && <Marker position={[marker.lat, marker.lng]} />}
            </MapContainer>

            {/* Hint overlay */}
            {!marker && (
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-black/70 text-white text-xs px-3 py-1.5 rounded-full pointer-events-none z-[1000]">
                Nhấn vào bản đồ để chọn vị trí
              </div>
            )}
          </div>

          {marker && (
            <div className="flex items-center justify-between px-3 py-2 bg-green-50 border-t border-green-200 text-xs">
              <span className="flex items-center gap-1.5 text-green-700">
                <MapPin className="w-3.5 h-3.5" />
                Đã chọn vị trí — {marker.lat.toFixed(5)}, {marker.lng.toFixed(5)}
              </span>
              <button
                type="button"
                onClick={() => { setMarker(null); onMapsLinkChange(''); }}
                className="text-green-600 hover:text-red-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {mapsLink && (
        <a href={mapsLink} target="_blank" rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-xs text-primary hover:underline">
          <MapPin className="w-3 h-3" /> Xem trên Google Maps
        </a>
      )}
    </div>
  );
}