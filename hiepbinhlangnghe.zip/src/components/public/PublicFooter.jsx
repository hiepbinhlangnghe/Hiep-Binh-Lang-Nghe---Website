import React from 'react';

export default function PublicFooter() {
  return (
    <footer className="mt-auto border-t border-gray-200 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <img src="https://media.base44.com/images/public/69f58e8c299b3c5e4bfd8065/dd93283d3_Quoc_Huy_Viet_Nam_Chuan.png"

              alt="Quốc huy" className="w-10 h-10 object-contain" />

              
              <div>
                <h3 className="font-bold text-gray-800 leading-tight">Hiệp Bình Lắng Nghe</h3>
                
              </div>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">
              Cổng tiếp nhận phản ánh, kiến nghị của người dân phường Hiệp Bình. Cam kết xử lý kịp thời, minh bạch.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-gray-700 mb-3 text-xs uppercase tracking-widest">Liên hệ</h4>
            <div className="space-y-1.5 text-sm text-gray-500">
              <p>Phường Hiệp Bình, TP. Hồ Chí Minh</p>
              <p>(028) xxxx xxxx</p>
              <a href="mailto:hiepbinhlangnghe@gmail.com" className="hover:text-gray-800 transition-colors">
                hiepbinhlangnghe@gmail.com
              </a>
            </div>
          </div>
        </div>
      </div>

      

      
    </footer>);

}