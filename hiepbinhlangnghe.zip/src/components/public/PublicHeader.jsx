import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const NAV_LINKS = [
{ to: '/', label: 'TRANG CHỦ' },
{ to: '/submit', label: 'GỬI PHẢN ÁNH' },
{ to: '/track', label: 'TRA CỨU HỒ SƠ' },
{ to: '/admin/dashboard', label: 'ĐĂNG NHẬP', admin: true }];


export default function PublicHeader() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const isActive = (path) => path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);

  return (
    <header className="sticky top-0 z-50 shadow-sm">
      {/* Thin red top stripe */}
      <div className="h-0.5 bg-[#c8102e]" />

      {/* Logo area */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-3 flex flex-col items-center md:flex-row md:items-center md:justify-between gap-2">
          <Link to="/" className="flex items-center gap-4">
            <img src="https://media.base44.com/images/public/69f58e8c299b3c5e4bfd8065/dd93283d3_Quoc_Huy_Viet_Nam_Chuan.png"

            alt="Quốc huy Việt Nam" className="w-14 h-14 md:w-16 md:h-16 object-contain" />
            
            
            <div className="text-center md:text-left" style={{ fontFamily: "'Times New Roman', Times, serif" }}>
              

              
              <h1 className="text-xl md:text-2xl font-extrabold text-gray-800 leading-tight">
                Hiệp Bình Lắng Nghe
              </h1>
              

              
            </div>
          </Link>

          <div className="hidden md:block text-right text-sm text-gray-400">
            
            <p className="text-xs mt-0.5">Cổng tiếp nhận phản ánh trực tuyến</p>
          </div>
        </div>
      </div>

      {/* Navigation bar — light grey */}
      <div className="bg-gray-100 border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4">
          <nav className="hidden md:flex items-center">
            {NAV_LINKS.map((link) =>
            <Link
              key={link.to}
              to={link.to}
              className={`px-5 py-2.5 text-sm font-semibold tracking-wide transition-all border-b-2 whitespace-nowrap ${
              isActive(link.to) ?
              'border-[#c8102e] text-[#c8102e] bg-white' :
              'border-transparent text-gray-600 hover:text-gray-900 hover:bg-white'} ${
              link.admin ? 'ml-auto text-gray-500 hover:text-gray-800' : ''}`}>
              
                {link.label}
              </Link>
            )}
          </nav>

          <div className="md:hidden flex items-center justify-between py-2">
            <span className="text-sm font-semibold text-gray-700">UBND Phường Hiệp Bình</span>
            <button className="p-1.5 text-gray-600" onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {mobileOpen &&
      <div className="md:hidden bg-white border-b border-gray-200">
          <div className="max-w-6xl mx-auto px-4 py-2 flex flex-col">
            {NAV_LINKS.map((link) =>
          <Link
            key={link.to}
            to={link.to}
            onClick={() => setMobileOpen(false)}
            className={`px-4 py-2.5 text-sm font-semibold ${
            isActive(link.to) ? 'text-[#c8102e]' : 'text-gray-600 hover:text-gray-900'}`
            }>
            
                {link.label}
              </Link>
          )}
          </div>
        </div>
      }
    </header>);

}