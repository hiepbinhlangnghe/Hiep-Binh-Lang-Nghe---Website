import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

const fadeUp = { initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 } };

export default function Home() {
  return (
    <div className="bg-white">

      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-2 flex items-center gap-2 text-xs text-gray-400">
          <span className="font-medium text-[#c8102e]">TRANG CHỦ</span>
          <ChevronRight className="w-3 h-3" />
          <span>Cổng tiếp nhận phản ánh, kiến nghị</span>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8 md:py-12">
        <div className="flex flex-col lg:flex-row gap-10">

          {/* Left: main content */}
          <div className="flex-1">
            <motion.div {...fadeUp} transition={{ duration: 0.4 }}>
              <h2 className="text-xl md:text-2xl font-bold text-gray-800 mb-1 uppercase tracking-wide">
                Tiếp Nhận Phản Ánh, Kiến Nghị Của Người Dân
              </h2>
              <div className="h-0.5 w-14 bg-[#c8102e] mb-6" />
              <p className="text-gray-500 text-sm md:text-base mb-8 leading-relaxed">
                UBND Phường Hiệp Bình trân trọng tiếp nhận phản ánh, kiến nghị từ người dân về các vấn đề liên quan đến đời sống, trật tự, môi trường và quản lý đô thị trên địa bàn phường.
              </p>
            </motion.div>

            {/* Quick action cards */}
            <motion.div {...fadeUp} transition={{ delay: 0.1 }} className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
              <Link to="/submit" className="group">
                <div className="p-5 border border-gray-200 rounded bg-white hover:border-[#c8102e] hover:shadow-sm transition-all">
                  <p className="text-xs uppercase tracking-widest text-gray-400 mb-1">Dịch vụ trực tuyến</p>
                  <h3 className="font-bold text-gray-800 text-base group-hover:text-[#c8102e] transition-colors">Gửi phản ánh</h3>
                  <p className="text-xs text-gray-400 mt-1">Gửi kiến nghị trực tuyến ngay hôm nay</p>
                  <div className="mt-3 text-xs font-semibold text-[#c8102e] flex items-center gap-1">
                    Bắt đầu <ChevronRight className="w-3 h-3" />
                  </div>
                </div>
              </Link>
              <Link to="/track" className="group">
                <div className="p-5 border border-gray-200 rounded bg-white hover:border-gray-400 hover:shadow-sm transition-all">
                  <p className="text-xs uppercase tracking-widest text-gray-400 mb-1">Tra cứu</p>
                  <h3 className="font-bold text-gray-800 text-base group-hover:text-gray-900 transition-colors">Tra cứu hồ sơ</h3>
                  <p className="text-xs text-gray-400 mt-1">Kiểm tra tình trạng xử lý phản ánh</p>
                  <div className="mt-3 text-xs font-semibold text-gray-500 flex items-center gap-1">
                    Tra cứu <ChevronRight className="w-3 h-3" />
                  </div>
                </div>
              </Link>
            </motion.div>

            {/* Process */}
            <motion.div {...fadeUp} transition={{ delay: 0.15 }}>
              <h3 className="text-sm font-bold text-gray-700 uppercase tracking-widest mb-4 flex items-center gap-2">
                <div className="w-1 h-4 bg-[#c8102e] rounded-full" />
                Quy trình xử lý phản ánh
              </h3>
              <div className="space-y-2">
                {[
                { step: '01', title: 'Gửi phản ánh', desc: 'Người dân điền thông tin và gửi trực tuyến. Hệ thống cấp mã hồ sơ ngay lập tức.' },
                { step: '02', title: 'Tiếp nhận & Phân loại', desc: 'Bộ phận tiếp nhận xem xét, phân loại và chuyển phòng ban xử lý trong 24 giờ.' },
                { step: '03', title: 'Xử lý & Phản hồi', desc: 'Phòng ban chuyên môn giải quyết và thông báo kết quả đến người dân.' }].
                map((item, i) =>
                <div key={i} className="flex gap-4 p-4 bg-gray-50 border border-gray-100 rounded">
                    <span className="text-2xl font-black text-gray-200 leading-none w-10 shrink-0">{item.step}</span>
                    <div>
                      <p className="font-semibold text-sm text-gray-700 mb-0.5">{item.title}</p>
                      <p className="text-xs text-gray-400 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>

          {/* Right sidebar */}
          <div className="w-full lg:w-64 shrink-0 space-y-5">

            {/* Map */}
            <motion.div {...fadeUp} transition={{ delay: 0.2 }}>
              <div className="border border-gray-200 rounded overflow-hidden">
                <div className="bg-gray-800 px-4 py-2.5 hidden">
                  <h4 className="text-xs font-bold text-white uppercase tracking-widest text-center hidden">Bản Đồ Hành Chính</h4>
                </div>
                <div className="p-2 bg-white">
                  <img src="https://media.base44.com/images/public/69f58e8c299b3c5e4bfd8065/ef4d62657_bandophuonghiepbinh.png"

                  alt="Bản đồ phường Hiệp Bình" className="w-full rounded object-cover"

                  style={{ minHeight: '200px' }} />
                  
                  <p className="text-center text-xs text-gray-400 mt-2 pb-1">
                    © Bản đồ phường Hiệp Bình, TP. Thủ Đức
                  </p>
                </div>
              </div>
            </motion.div>


          </div>
        </div>
      </div>


    </div>);

}