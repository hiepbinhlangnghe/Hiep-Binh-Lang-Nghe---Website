import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Loader2, Upload, X, CheckCircle2, AlertCircle } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

export default function ResolveIssue() {
  const { token } = useParams();
  const [note, setNote] = useState('');
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  const handleFileUpload = async (e) => {
    const selected = Array.from(e.target.files);
    if (!selected.length) return;
    setUploading(true);
    try {
      for (const file of selected) {
        if (file.size > 10 * 1024 * 1024) { toast.error(`File "${file.name}" vượt quá 10MB`); continue; }
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        setFiles(prev => [...prev, { name: file.name, url: file_url }]);
      }
    } catch {
      toast.error('Không thể tải file lên');
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!note.trim()) { toast.error('Vui lòng nhập ghi chú kết quả xử lý'); return; }
    if (!files.length) { toast.error('Vui lòng đính kèm ít nhất 1 hình ảnh hoặc tài liệu'); return; }

    setSubmitting(true);
    setError('');
    try {
      await base44.functions.invoke('resolveIssue', {
        token,
        resolution_note: note,
        result_attachments: files.map(f => f.url)
      });
      setDone(true);
    } catch (err) {
      const msg = err?.response?.data?.error || 'Có lỗi xảy ra, vui lòng thử lại';
      setError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="bg-white border border-gray-200 rounded-lg max-w-md w-full p-8 text-center shadow-sm">
          <CheckCircle2 className="w-14 h-14 text-green-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-800 mb-2" style={{ fontFamily: "'Times New Roman', Times, serif" }}>
            Đã ghi nhận kết quả
          </h2>
          <div className="h-0.5 w-12 bg-[#c8102e] mx-auto mb-4" />
          <p className="text-gray-500 text-sm">
            Kết quả xử lý đã được cập nhật vào hệ thống thành công. Cảm ơn bộ phận đã xử lý phản ánh này.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Gov top bar */}
      <div className="h-1" style={{ background: 'linear-gradient(90deg, #c8102e 0%, #c8102e 50%, #f5c518 50%, #f5c518 100%)' }} />

      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-3">
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Emblem_of_Vietnam.svg/240px-Emblem_of_Vietnam.svg.png"
            alt="Quốc huy" className="w-10 h-10 object-contain"
          />
          <div>
            <h1 className="font-bold text-gray-800 text-sm leading-tight">Hiệp Bình Lắng Nghe</h1>
            <p className="text-xs text-gray-400">UBND Phường Hiệp Bình — TP. Hồ Chí Minh</p>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          <div className="bg-gray-700 px-6 py-4">
            <h2 className="text-white font-bold uppercase tracking-wide text-sm">Báo cáo kết quả xử lý</h2>
            <p className="text-gray-300 text-xs mt-1">Vui lòng điền đầy đủ thông tin và đính kèm hình ảnh minh chứng</p>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {error && (
              <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded text-sm text-red-700">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                {error}
              </div>
            )}

            {/* Ghi chú */}
            <div>
              <label className="block text-sm font-semibold text-gray-600 uppercase tracking-wide mb-2">
                Ghi chú kết quả xử lý <span className="text-[#c8102e]">*</span>
              </label>
              <Textarea
                rows={5}
                placeholder="Mô tả chi tiết kết quả xử lý, các biện pháp đã thực hiện..."
                value={note}
                onChange={e => setNote(e.target.value)}
                className="rounded border-gray-300 focus-visible:ring-gray-400 resize-none"
              />
            </div>

            {/* File upload */}
            <div>
              <label className="block text-sm font-semibold text-gray-600 uppercase tracking-wide mb-2">
                Hình ảnh / Tài liệu minh chứng <span className="text-[#c8102e]">*</span>
              </label>
              <label htmlFor="resolve-upload" className="cursor-pointer inline-block">
                <div className="flex items-center gap-2 px-4 py-2 border border-gray-300 bg-gray-50 hover:bg-gray-100 rounded text-sm font-medium text-gray-700 transition-colors">
                  {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  Chọn file đính kèm
                </div>
                <input
                  type="file"
                  id="resolve-upload"
                  multiple
                  accept="image/*,.pdf,.doc,.docx"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
              <p className="text-xs text-gray-400 mt-1">Chấp nhận: .jpg, .png, .pdf, .doc, .docx (tối đa 10MB/file)</p>

              {files.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {files.map((f, i) => (
                    <span key={i} className="inline-flex items-center gap-1.5 bg-gray-100 text-xs px-3 py-1.5 rounded text-gray-700">
                      {f.name}
                      <button type="button" onClick={() => setFiles(prev => prev.filter((_, idx) => idx !== i))}>
                        <X className="w-3 h-3 text-gray-400 hover:text-red-500" />
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={submitting || uploading}
                className="flex items-center gap-2 px-8 py-2.5 bg-gray-700 hover:bg-gray-800 text-white font-bold text-sm uppercase tracking-wide rounded transition-colors disabled:opacity-60"
              >
                {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                Xác nhận hoàn thành
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}