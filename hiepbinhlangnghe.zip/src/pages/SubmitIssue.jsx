import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2, Upload, X, ChevronRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { CATEGORIES, SUBCATEGORIES } from '@/lib/constants';
import { toast } from 'sonner';
import LocationPicker from '@/components/public/LocationPicker';

const Row = ({ label, required, children }) => (
  <div className="flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-0 border-b border-gray-100 last:border-0 py-4">
    <div className="sm:w-44 shrink-0 pt-1">
      <label className="text-sm font-semibold text-gray-600 uppercase tracking-wide">
        {label} {required && <span className="text-[#c8102e] ml-0.5">*</span>}
      </label>
    </div>
    <div className="flex-1">{children}</div>
  </div>
);

export default function SubmitIssue() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formError, setFormError] = useState('');
  const [form, setForm] = useState({
    full_name: '', phone: '', email: '', citizen_address: '',
    category: '', subcategory: '', title: '', description: '',
    issue_address: '', maps_link: '', attachments: [], confirmed: false
  });

  const set = (key, val) => setForm((prev) => ({ ...prev, [key]: typeof val === 'function' ? val(prev[key]) : val }));

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;
    setUploading(true);
    try {
      for (const file of files) {
        if (file.size > 10 * 1024 * 1024) {toast.error(`File "${file.name}" vượt quá 10MB`);continue;}
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        set('attachments', (prev) => [...prev, file_url]);
      }
    } catch {toast.error('Không thể tải file lên');} finally
    {setUploading(false);}
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError('');
    if (!form.confirmed) { setFormError('Vui lòng xác nhận thông tin trước khi gửi.'); return; }
    if (!form.full_name) { setFormError('Vui lòng nhập họ và tên.'); return; }
    if (!form.email) { setFormError('Vui lòng nhập email.'); return; }
    if (!form.phone) { setFormError('Vui lòng nhập số điện thoại.'); return; }
    if (!form.category) { setFormError('Vui lòng chọn lĩnh vực.'); return; }
    if (!form.subcategory) { setFormError('Vui lòng chọn nhóm vấn đề.'); return; }
    if (!form.title) { setFormError('Vui lòng nhập tiêu đề.'); return; }
    if (!form.description) { setFormError('Vui lòng nhập nội dung phản ánh.'); return; }
    if (!form.issue_address) { setFormError('Vui lòng nhập địa chỉ sự việc.'); return; }
    setLoading(true);
    try {
      const res = await base44.functions.invoke('submitIssue', {
        full_name: form.full_name, phone: form.phone, email: form.email,
        citizen_address: form.citizen_address, category: form.category,
        subcategory: form.subcategory, title: form.title, description: form.description,
        issue_address: form.issue_address, maps_link: form.maps_link, attachments: form.attachments
      });
      navigate('/submit/success', { state: { tracking_code: res.data.tracking_code } });
    } catch (err) {
      setFormError(err?.response?.data?.error || 'Có lỗi xảy ra, vui lòng thử lại.');
    } finally { setLoading(false); }
  };

  return (
    <div className="bg-white min-h-screen">
      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-2 flex items-center gap-2 text-xs text-gray-400">
          <Link to="/" className="font-medium text-[#c8102e] hover:underline">TRANG CHỦ</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-gray-600 font-medium">TIẾP NHẬN PHẢN ÁNH KIẾN NGHỊ CỦA CÔNG DÂN</span>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8 md:py-10">
        <div className="flex flex-col lg:flex-row gap-8">

          {/* Main form */}
          <div className="flex-1">
            <h2 className="text-lg md:text-xl font-bold text-gray-800 uppercase tracking-wide mb-1" style={{ fontFamily: "'Times New Roman', Times, serif" }}>
              Tiếp Nhận Phản Ánh, Kiến Nghị Của Công Dân
            </h2>
            <div className="h-0.5 w-16 bg-[#c8102e] mb-6" />

            <form onSubmit={handleSubmit} className="bg-white border border-gray-200 rounded px-5 md:px-8 py-2">

              <Row label="Họ và tên" required>
                <Input
                  placeholder="Nguyễn Văn A"
                  value={form.full_name}
                  onChange={(e) => set('full_name', e.target.value)}
                  className="rounded-none border-0 border-b border-gray-200 focus-visible:ring-0 focus-visible:border-gray-500 px-0" />
                
              </Row>

              <Row label="Email" required>
                <Input
                  type="email"
                  placeholder="email@example.com"
                  value={form.email}
                  onChange={(e) => set('email', e.target.value)}
                  className="rounded-none border-0 border-b border-gray-200 focus-visible:ring-0 focus-visible:border-gray-500 px-0" />
                
              </Row>

              <Row label="Số điện thoại" required>
                <Input
                  placeholder="0901234567"
                  value={form.phone}
                  onChange={(e) => set('phone', e.target.value)}
                  className="rounded-none border-0 border-b border-gray-200 focus-visible:ring-0 focus-visible:border-gray-500 px-0" />
                
              </Row>

              <Row label="Địa chỉ">
                <Input
                  placeholder="Số nhà, đường, phường..."
                  value={form.citizen_address}
                  onChange={(e) => set('citizen_address', e.target.value)}
                  className="rounded-none border-0 border-b border-gray-200 focus-visible:ring-0 focus-visible:border-gray-500 px-0" />
                
              </Row>

              <Row label="Lĩnh vực" required>
                <Select value={form.category} onValueChange={(v) => {set('category', v);set('subcategory', '');}}>
                  <SelectTrigger className="rounded-none border-0 border-b border-gray-200 focus:ring-0 px-0">
                    <SelectValue placeholder="— Chọn lĩnh vực —" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Row>

              {form.category &&
              <Row label="Nhóm vấn đề" required>
                  <Select value={form.subcategory} onValueChange={(v) => set('subcategory', v)}>
                    <SelectTrigger className="rounded-none border-0 border-b border-gray-200 focus:ring-0 px-0">
                      <SelectValue placeholder="— Chọn nhóm vấn đề —" />
                    </SelectTrigger>
                    <SelectContent>
                      {(SUBCATEGORIES[form.category] || []).map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </Row>
              }

              <Row label="Tiêu đề" required>
                <Input
                  placeholder="Tóm tắt nội dung phản ánh"
                  value={form.title}
                  onChange={(e) => set('title', e.target.value)}
                  className="rounded-none border-0 border-b border-gray-200 focus-visible:ring-0 focus-visible:border-gray-500 px-0" />
                
              </Row>

              <Row label="Files đính kèm">
                <div>
                  <div className="flex items-center gap-3">
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <div className="flex items-center gap-2 px-4 py-1.5 border border-border bg-secondary hover:bg-border text-sm font-medium rounded transition-colors">
                        {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                        CHỌN FILE
                      </div>
                      <input type="file" multiple accept="image/*,.pdf,.doc,.docx" onChange={handleFileUpload} className="hidden" id="file-upload" />
                    </label>
                    <span className="text-sm text-gray-400">
                     {form.attachments.length > 0 ? `${form.attachments.length} file đã chọn` : 'No file chosen'}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mt-2">Chỉ nhận file .doc, .docx, .pdf, .jpg, .jpeg, .png</p>
                  {form.attachments.length > 0 &&
                  <div className="flex flex-wrap gap-1.5 mt-2">
                      {form.attachments.map((_, i) =>
                    <span key={i} className="inline-flex items-center gap-1 bg-gray-100 text-xs px-2 py-1 rounded">
                          File {i + 1}
                          <button type="button" onClick={() => set('attachments', form.attachments.filter((__, idx) => idx !== i))}>
                            <X className="w-3 h-3 text-muted-foreground hover:text-destructive" />
                          </button>
                        </span>
                    )}
                    </div>
                  }
                </div>
              </Row>

              <Row label="Nội dung" required>
                <Textarea
                  rows={7}
                  placeholder="Mô tả chi tiết vấn đề phản ánh..."
                  value={form.description}
                  onChange={(e) => set('description', e.target.value)}
                  className="rounded-none border-0 border-b border-gray-200 focus-visible:ring-0 focus-visible:border-gray-500 px-0 resize-none" />
                
              </Row>

              <Row label="Địa chỉ sự việc" required>
                <LocationPicker
                  value={form.issue_address}
                  mapsLink={form.maps_link}
                  onChange={(val) => set('issue_address', val)}
                  onMapsLinkChange={(val) => set('maps_link', val)}
                />
              </Row>

              {/* Confirm + Submit */}
              <div className="py-5 space-y-4">
                <div className="flex items-start gap-3 p-4 bg-gray-50 border border-gray-200 rounded">
                  <Checkbox id="confirm" checked={form.confirmed} onCheckedChange={(v) => set('confirmed', v)} className="mt-0.5" />
                  <label htmlFor="confirm" className="text-sm leading-relaxed cursor-pointer text-foreground">
                    Tôi cam kết thông tin nêu trên là đúng sự thật và chịu trách nhiệm trước pháp luật về nội dung phản ánh này.
                  </label>
                </div>

                {formError && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded text-sm text-red-700 font-medium">
                    ⚠️ {formError}
                  </div>
                )}
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex items-center gap-2 px-8 py-2.5 bg-gray-700 text-white font-bold text-sm uppercase tracking-wide rounded hover:bg-gray-800 transition-colors disabled:opacity-60">
                    {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                    GỬI PHẢN ÁNH
                  </button>
                </div>
              </div>
            </form>
          </div>

          {/* Right sidebar */}
          <div className="w-full lg:w-64 shrink-0 space-y-5">
            {/* Map */}
            <div className="border border-gray-200 rounded overflow-hidden">
              

              
              <div className="p-2 bg-white">
                <img src="https://media.base44.com/images/public/69f58e8c299b3c5e4bfd8065/ef4d62657_bandophuonghiepbinh.png"

                alt="Bản đồ phường Hiệp Bình" className="w-full rounded object-cover"

                style={{ minHeight: '200px' }} />
                
                <p className="text-center text-xs text-gray-400 mt-2 pb-1">
                  © Bản đồ phường Hiệp Bình, TP. Thủ Đức
                </p>
              </div>
            </div>

            {/* Note box */}
            <div className="border border-gray-200 rounded overflow-hidden">
              <div className="bg-gray-700 px-4 py-2.5">
                <h4 className="text-xs font-bold text-white uppercase tracking-widest text-center">Lưu Ý</h4>
              </div>
              <div className="p-4 bg-white text-xs text-gray-500 space-y-2 leading-relaxed">
                <p>• Các trường có dấu <span className="text-[#c8102e] font-bold">*</span> là bắt buộc.</p>
                <p>• Thông tin cá nhân được bảo mật tuyệt đối.</p>
                <p>• Sau khi gửi, bạn sẽ nhận mã hồ sơ để theo dõi.</p>
                <p>• Thời gian xử lý tối đa <strong>30 ngày làm việc</strong>.</p>
                <p>• Cung cấp thông tin sai sự thật là vi phạm pháp luật.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>);

}