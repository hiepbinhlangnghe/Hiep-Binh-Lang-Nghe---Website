import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { CheckCircle2, Copy, Search, Home, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';

export default function SubmitSuccess() {
  const location = useLocation();
  const trackingCode = location.state?.tracking_code || 'N/A';

  const copyCode = () => {
    navigator.clipboard.writeText(trackingCode);
    toast.success('Đã sao chép mã hồ sơ');
  };

  return (
    <div className="bg-white min-h-screen">
      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-2 flex items-center gap-2 text-xs text-gray-400">
          <Link to="/" className="font-medium text-[#c8102e] hover:underline">TRANG CHỦ</Link>
          <ChevronRight className="w-3 h-3" />
          <Link to="/submit" className="hover:underline">GỬI PHẢN ÁNH</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-gray-600 font-medium">KẾT QUẢ</span>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-12 md:py-16">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <CheckCircle2 className="w-12 h-12 text-green-600" />
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2" style={{ fontFamily: "'Times New Roman', Times, serif" }}>
            Gửi phản ánh thành công
          </h1>
          <div className="h-0.5 w-14 bg-[#c8102e] mx-auto mb-4" />
          <p className="text-gray-500 text-sm">
            Phản ánh của bạn đã được ghi nhận. Chúng tôi sẽ xử lý trong thời gian sớm nhất.
          </p>
        </div>

        {/* Tracking code box */}
        <div className="border border-gray-200 rounded bg-white mb-8">
          <div className="bg-gray-700 px-4 py-2.5">
            <h4 className="text-xs font-bold text-white uppercase tracking-widest text-center">Mã hồ sơ của bạn</h4>
          </div>
          <div className="p-6 text-center">
            <div className="flex items-center justify-center gap-3 mb-2">
              <span className="text-2xl font-bold text-gray-800 tracking-wider font-mono">{trackingCode}</span>
              <button
                onClick={copyCode}
                className="p-1.5 hover:bg-gray-100 rounded transition-colors"
                title="Sao chép mã"
              >
                <Copy className="w-4 h-4 text-gray-500" />
              </button>
            </div>
            <p className="text-xs text-gray-400">Hãy lưu lại mã này để tra cứu tình trạng xử lý</p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Link to="/track" className="flex-1">
            <button className="w-full flex items-center justify-center gap-2 px-6 py-2.5 border border-gray-300 bg-white text-gray-700 font-semibold text-sm uppercase tracking-wide rounded hover:bg-gray-50 transition-colors">
              <Search className="w-4 h-4" />
              Tra cứu hồ sơ
            </button>
          </Link>
          <Link to="/" className="flex-1">
            <button className="w-full flex items-center justify-center gap-2 px-6 py-2.5 bg-gray-700 text-white font-semibold text-sm uppercase tracking-wide rounded hover:bg-gray-800 transition-colors">
              <Home className="w-4 h-4" />
              Trang chủ
            </button>
          </Link>
        </div>

        {/* Info note */}
        <div className="mt-8 border border-gray-200 rounded p-4 bg-gray-50 text-xs text-gray-500 space-y-1.5 leading-relaxed">
          <p>• Thời gian xử lý tối đa <strong>30 ngày làm việc</strong> kể từ ngày tiếp nhận.</p>
          <p>• Bạn có thể tra cứu tình trạng xử lý bất cứ lúc nào bằng mã hồ sơ ở trên.</p>
          <p>• Kết quả xử lý sẽ được thông báo qua email đã đăng ký.</p>
        </div>
      </div>
    </div>
  );
}