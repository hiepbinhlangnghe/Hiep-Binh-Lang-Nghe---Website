import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Loader2, FileSearch, Clock, CheckCircle, Building2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { STATUS_MAP, CATEGORIES, DEPARTMENT_MAP } from '@/lib/constants';
import { format } from 'date-fns';
import { vi } from 'date-fns/locale';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

export default function TrackIssue() {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!code.trim()) return;
    setLoading(true);
    setResult(null);
    try {
      const res = await base44.functions.invoke('trackIssue', { tracking_code: code.trim().toUpperCase() });
      setResult(res.data);
    } catch (err) {
      toast.error(err?.response?.data?.error || 'Không tìm thấy hồ sơ');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (d) => {
    if (!d) return '—';
    return format(new Date(d), "dd/MM/yyyy 'lúc' HH:mm", { locale: vi });
  };

  const getCategoryLabel = (val) => CATEGORIES.find(c => c.value === val)?.label || val;
  const statusInfo = result ? (STATUS_MAP[result.status] || STATUS_MAP.NEW) : null;

  const timelineSteps = result ? [
    { label: 'Gửi phản ánh', date: result.created_date, done: true },
    { label: 'Tiếp nhận', date: result.received_at, done: !!result.received_at },
    { label: 'Chuyển xử lý', date: result.forwarded_at, done: !!result.forwarded_at },
    { label: 'Hoàn thành', date: result.resolved_at, done: !!result.resolved_at }
  ] : [];

  return (
    <div className="bg-white min-h-screen">
      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-2 flex items-center gap-2 text-xs text-gray-400">
          <Link to="/" className="font-medium text-[#c8102e] hover:underline">TRANG CHỦ</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-gray-600 font-medium">TRA CỨU HỒ SƠ</span>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8 md:py-12">
        <div className="text-center mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2" style={{ fontFamily: "'Times New Roman', Times, serif" }}>
            Tra cứu hồ sơ
          </h1>
          <p className="text-gray-400">Nhập mã hồ sơ để xem tình trạng xử lý phản ánh</p>
        </div>

        <div className="border border-gray-200 rounded bg-white p-6 mb-8">
          <form onSubmit={handleSearch} className="flex gap-3">
            <Input
              placeholder="Nhập mã hồ sơ (VD: HB-20260502-1234)"
              value={code}
              onChange={e => setCode(e.target.value)}
              className="flex-1 text-base border-gray-300 focus-visible:ring-gray-400"
            />
            <button
              type="submit"
              disabled={loading || !code.trim()}
              className="px-5 bg-gray-700 hover:bg-gray-800 text-white rounded text-sm font-medium transition-colors disabled:opacity-50 flex items-center gap-2"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            </button>
          </form>
        </div>

        {result && (
          <div className="border border-gray-200 rounded bg-white">
            <div className="p-5 border-b border-gray-100">
              <div className="flex items-start justify-between flex-wrap gap-3">
                <div>
                  <h2 className="text-base font-bold text-gray-800">{result.title}</h2>
                  <p className="text-sm text-gray-400 mt-1">{result.tracking_code}</p>
                </div>
                <Badge className={statusInfo.color}>
                  <span className={`w-2 h-2 rounded-full ${statusInfo.dot} mr-2`} />
                  {statusInfo.label}
                </Badge>
              </div>
            </div>
            <div className="p-5 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-400 mb-0.5">Lĩnh vực</p>
                  <p className="font-medium text-gray-700">{getCategoryLabel(result.category)}</p>
                  {result.subcategory && <p className="text-xs text-gray-400">{result.subcategory}</p>}
                </div>
                {result.assigned_department && (
                  <div>
                    <p className="text-gray-400 mb-0.5">Bộ phận xử lý</p>
                    <p className="font-medium text-gray-700">{DEPARTMENT_MAP[result.assigned_department] || result.assigned_department}</p>
                  </div>
                )}
              </div>

              {/* Timeline */}
              <div>
                <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-4">Tiến trình xử lý</h3>
                <div className="space-y-0">
                  {timelineSteps.map((s, i) => (
                    <div key={i} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-white text-xs ${
                          s.done ? 'bg-gray-700' : 'bg-gray-200'
                        }`}>
                          {s.done ? <CheckCircle className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5 text-gray-400" />}
                        </div>
                        {i < timelineSteps.length - 1 && (
                          <div className={`w-0.5 h-8 ${s.done ? 'bg-gray-400' : 'bg-gray-200'}`} />
                        )}
                      </div>
                      <div className="pb-6">
                        <p className={`font-medium text-sm ${s.done ? 'text-gray-700' : 'text-gray-400'}`}>{s.label}</p>
                        <p className="text-xs text-gray-400">{s.date ? formatDate(s.date) : 'Chưa cập nhật'}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {result.resolution_note && (
                <div className="bg-gray-50 border border-gray-200 rounded p-4">
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">Kết quả xử lý</h3>
                  <p className="text-sm text-gray-600">{result.resolution_note}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {!result && !loading && (
          <div className="text-center py-12 text-gray-300">
            <FileSearch className="w-12 h-12 mx-auto mb-4" />
            <p className="text-gray-400">Nhập mã hồ sơ để bắt đầu tra cứu</p>
          </div>
        )}
      </div>
    </div>
  );
}