import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Users, Phone, Mail, MapPin, Shield, X, ArrowRight } from 'lucide-react';
import { useOutletContext, Navigate, Link } from 'react-router-dom';
import { format } from 'date-fns';
import { vi } from 'date-fns/locale';
import { STATUS_MAP } from '@/lib/constants';

export default function CitizenList() {
  const { user } = useOutletContext();
  const [search, setSearch] = useState('');
  const [selectedCitizen, setSelectedCitizen] = useState(null);

  const isAdmin = user?.role === 'admin';

  const { data: citizens = [], isLoading } = useQuery({
    queryKey: ['citizens'],
    queryFn: () => base44.entities.CitizenInfo.list('-created_date', 500),
    enabled: isAdmin
  });

  const { data: issues = [] } = useQuery({
    queryKey: ['admin-issues-all'],
    queryFn: () => base44.entities.Issue.list('-created_date', 500),
    enabled: isAdmin
  });

  // Chỉ admin được truy cập
  if (user && !isAdmin) {
    return <Navigate to="/admin/dashboard" replace />;
  }

  // Build map citizen_id -> số lượng phản ánh
  const issueCountByCitizen = {};
  for (const issue of issues) {
    if (issue.citizen_id) {
      issueCountByCitizen[issue.citizen_id] = (issueCountByCitizen[issue.citizen_id] || 0) + 1;
    }
  }

  const filtered = citizens.filter(c => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      c.full_name?.toLowerCase().includes(q) ||
      c.phone?.toLowerCase().includes(q) ||
      c.email?.toLowerCase().includes(q) ||
      c.citizen_address?.toLowerCase().includes(q)
    );
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-foreground">Thông tin người dân</h1>
            <Badge variant="secondary" className="bg-red-100 text-red-700 text-xs flex items-center gap-1">
              <Shield className="w-3 h-3" /> Chỉ Admin
            </Badge>
          </div>
          <p className="text-muted-foreground text-sm mt-1">{filtered.length} người dân đã gửi phản ánh</p>
        </div>
      </div>

      {/* Search */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Tìm theo tên, số điện thoại, email..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="border-0 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="text-left p-3 font-medium text-muted-foreground">Họ và tên</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Số điện thoại</th>
                <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">Email</th>
                <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Địa chỉ thường trú</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Số phản ánh</th>
                <th className="text-left p-3 font-medium text-muted-foreground hidden sm:table-cell">Ngày đăng ký</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filtered.map(citizen => (
                <tr key={citizen.id} className="hover:bg-muted/30">
                  <td className="p-3 font-medium">{citizen.full_name}</td>
                  <td className="p-3">
                    <a href={`tel:${citizen.phone}`} className="inline-flex items-center gap-1 text-primary hover:underline">
                      <Phone className="w-3.5 h-3.5" /> {citizen.phone}
                    </a>
                  </td>
                  <td className="p-3 hidden md:table-cell">
                    <a href={`mailto:${citizen.email}`} className="inline-flex items-center gap-1 text-muted-foreground hover:text-primary">
                      <Mail className="w-3.5 h-3.5" /> {citizen.email}
                    </a>
                  </td>
                  <td className="p-3 hidden lg:table-cell text-muted-foreground">
                    {citizen.citizen_address
                      ? <span className="inline-flex items-center gap-1"><MapPin className="w-3.5 h-3.5 shrink-0" />{citizen.citizen_address}</span>
                      : '—'}
                  </td>
                  <td className="p-3">
                    {(issueCountByCitizen[citizen.id] || 0) > 0 ? (
                      <button onClick={() => setSelectedCitizen(citizen)}>
                        <Badge variant="secondary" className="bg-primary/10 text-primary cursor-pointer hover:bg-primary/20">
                          {issueCountByCitizen[citizen.id]} phản ánh
                        </Badge>
                      </button>
                    ) : (
                      <Badge variant="secondary" className="text-muted-foreground">0 phản ánh</Badge>
                    )}
                  </td>
                  <td className="p-3 hidden sm:table-cell text-muted-foreground text-xs">
                    {format(new Date(citizen.created_date), 'dd/MM/yyyy', { locale: vi })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="w-10 h-10 mx-auto mb-3 opacity-30" />
              <p>Không có dữ liệu phù hợp</p>
            </div>
          )}
        </div>
      </Card>

      {/* Modal: danh sách phản ánh của người dân */}
      {selectedCitizen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b">
              <div>
                <h2 className="font-bold text-base">Phản ánh của: {selectedCitizen.full_name}</h2>
                <p className="text-xs text-muted-foreground mt-0.5">{selectedCitizen.phone} · {selectedCitizen.email}</p>
              </div>
              <button onClick={() => setSelectedCitizen(null)} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="overflow-y-auto flex-1 divide-y">
              {issues.filter(i => i.citizen_id === selectedCitizen.id).map(issue => {
                const si = STATUS_MAP[issue.status] || STATUS_MAP.NEW;
                return (
                  <Link
                    key={issue.id}
                    to={`/admin/issues/${issue.id}`}
                    onClick={() => setSelectedCitizen(null)}
                    className="flex items-center justify-between p-4 hover:bg-muted/40 group"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-semibold text-primary">{issue.tracking_code}</span>
                        <Badge className={si.color + ' text-xs'}>{si.label}</Badge>
                      </div>
                      <p className="text-sm font-medium line-clamp-1">{issue.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(issue.created_date), 'dd/MM/yyyy HH:mm', { locale: vi })}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary shrink-0 ml-2" />
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}