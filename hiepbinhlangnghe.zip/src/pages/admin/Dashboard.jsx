import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Clock, CheckCircle, AlertTriangle, TrendingUp } from 'lucide-react';
import { STATUS_MAP, CATEGORIES } from '@/lib/constants';
import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { vi } from 'date-fns/locale';

export default function Dashboard() {
  const { data: issues = [], isLoading } = useQuery({
    queryKey: ['admin-issues'],
    queryFn: () => base44.entities.Issue.list('-created_date', 100)
  });

  const stats = {
    total: issues.length,
    newCount: issues.filter(i => i.status === 'NEW').length,
    processing: issues.filter(i => ['RECEIVED', 'FORWARDED', 'IN_PROGRESS'].includes(i.status)).length,
    resolved: issues.filter(i => ['RESOLVED', 'NOTIFIED'].includes(i.status)).length,
    overdue: issues.filter(i => i.status === 'OVERDUE').length
  };

  const statCards = [
    { label: 'Tổng phản ánh', value: stats.total, icon: FileText, color: 'text-primary bg-primary/10' },
    { label: 'Chờ tiếp nhận', value: stats.newCount, icon: Clock, color: 'text-blue-600 bg-blue-100' },
    { label: 'Đang xử lý', value: stats.processing, icon: TrendingUp, color: 'text-orange-600 bg-orange-100' },
    { label: 'Đã xử lý', value: stats.resolved, icon: CheckCircle, color: 'text-green-600 bg-green-100' },
    { label: 'Quá hạn', value: stats.overdue, icon: AlertTriangle, color: 'text-red-600 bg-red-100' }
  ];

  const recentIssues = issues.slice(0, 8);
  const getCategoryLabel = (val) => CATEGORIES.find(c => c.value === val)?.label || val;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Tổng quan</h1>
        <p className="text-muted-foreground text-sm mt-1">Bảng điều khiển quản lý phản ánh người dân</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {statCards.map((s, i) => (
          <Card key={i} className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${s.color}`}>
                  <s.icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{s.value}</p>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent issues */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-base">Phản ánh gần đây</CardTitle>
          <Link to="/admin/issues" className="text-sm text-primary hover:underline">Xem tất cả</Link>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left">
                  <th className="pb-3 font-medium text-muted-foreground">Mã hồ sơ</th>
                  <th className="pb-3 font-medium text-muted-foreground">Tiêu đề</th>
                  <th className="pb-3 font-medium text-muted-foreground hidden md:table-cell">Lĩnh vực</th>
                  <th className="pb-3 font-medium text-muted-foreground">Trạng thái</th>
                  <th className="pb-3 font-medium text-muted-foreground hidden sm:table-cell">Ngày gửi</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {recentIssues.map(issue => {
                  const si = STATUS_MAP[issue.status] || STATUS_MAP.NEW;
                  return (
                    <tr key={issue.id} className="hover:bg-muted/50">
                      <td className="py-3">
                        <Link to={`/admin/issues/${issue.id}`} className="text-primary font-medium hover:underline">
                          {issue.tracking_code}
                        </Link>
                      </td>
                      <td className="py-3">
                        <Link to={`/admin/issues/${issue.id}`} className="hover:text-primary truncate max-w-[200px] block">
                          {issue.title}
                        </Link>
                      </td>
                      <td className="py-3 hidden md:table-cell text-muted-foreground">
                        {getCategoryLabel(issue.category)}
                      </td>
                      <td className="py-3">
                        <Badge variant="secondary" className={`${si.color} text-xs`}>
                          {si.label}
                        </Badge>
                      </td>
                      <td className="py-3 hidden sm:table-cell text-muted-foreground text-xs">
                        {format(new Date(issue.created_date), 'dd/MM/yyyy', { locale: vi })}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {recentIssues.length === 0 && (
              <p className="text-center py-8 text-muted-foreground">Chưa có phản ánh nào</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}