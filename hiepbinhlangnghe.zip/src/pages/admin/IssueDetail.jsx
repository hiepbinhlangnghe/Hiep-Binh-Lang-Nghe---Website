import React, { useState } from 'react';
import { useParams, useOutletContext, Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import {
  ArrowLeft, User, Phone, Mail, MapPin, Calendar, Building2, FileText,
  CheckCircle, Forward, Loader2, ExternalLink, Clock, Upload, X, Paperclip
} from 'lucide-react';
import { STATUS_MAP, CATEGORIES, DEPARTMENT_MAP, CATEGORY_TO_DEPARTMENT } from '@/lib/constants';
import { format } from 'date-fns';
import { vi } from 'date-fns/locale';
import { toast } from 'sonner';

export default function IssueDetail() {
  const { id } = useParams();
  const { user } = useOutletContext();
  const queryClient = useQueryClient();
  const [note, setNote] = useState('');
  const [resolutionNote, setResolutionNote] = useState('');
  const [resultFiles, setResultFiles] = useState([]);
  const [uploading, setUploading] = useState(false);

  const { data: issue, isLoading } = useQuery({
    queryKey: ['issue', id],
    queryFn: async () => {
      const items = await base44.entities.Issue.filter({ id });
      const issue = items[0];
      if (issue?.citizen_id) {
        const citizens = await base44.entities.CitizenInfo.filter({ id: issue.citizen_id });
        issue._citizen = citizens[0] || null;
      }
      return issue;
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ data }) => base44.entities.Issue.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['issue', id] });
      queryClient.invalidateQueries({ queryKey: ['admin-issues'] });
      queryClient.invalidateQueries({ queryKey: ['admin-issues-list'] });
      toast.success('Đã cập nhật');
    }
  });

  const handleReceive = () => {
    updateMutation.mutate({
      data: {
        status: 'RECEIVED',
        received_at: new Date().toISOString(),
        received_by: user?.email || '',
        staff_notes: note || issue?.staff_notes || ''
      }
    });
  };

  const handleForward = async () => {
    const dept = CATEGORY_TO_DEPARTMENT[issue?.category] || '';
    await updateMutation.mutateAsync({
      data: {
        status: 'FORWARDED',
        forwarded_at: new Date().toISOString(),
        assigned_department: dept,
        staff_notes: note || issue?.staff_notes || ''
      }
    });
    // Gửi email thông báo cho bộ phận xử lý
    try {
      await base44.functions.invoke('notifyDepartment', { issue_id: id });
      toast.success('Đã chuyển tiếp và gửi email thông báo cho bộ phận xử lý');
    } catch {
      toast.warning('Đã chuyển tiếp nhưng không gửi được email thông báo');
    }
  };

  const handleResolve = () => {
    if (!resolutionNote.trim()) {
      toast.error('Vui lòng nhập nội dung kết quả xử lý');
      return;
    }
    if (!resultFiles.length) {
      toast.error('Vui lòng đính kèm ít nhất 1 hình ảnh hoặc tài liệu minh chứng');
      return;
    }
    updateMutation.mutate({
      data: {
        status: 'RESOLVED',
        resolved_at: new Date().toISOString(),
        resolution_note: resolutionNote,
        result_attachments: resultFiles
      }
    });
  };

  const handleSaveNote = () => {
    updateMutation.mutate({ data: { staff_notes: note } });
  };

  const handleResultFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    setUploading(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        setResultFiles(prev => [...prev, file_url]);
      }
    } catch {
      toast.error('Lỗi khi tải file');
    } finally {
      setUploading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!issue) {
    return <div className="text-center py-16 text-muted-foreground">Không tìm thấy phản ánh</div>;
  }

  const si = STATUS_MAP[issue.status] || STATUS_MAP.NEW;
  const getCategoryLabel = (val) => CATEGORIES.find(c => c.value === val)?.label || val;
  const formatDate = (d) => d ? format(new Date(d), "dd/MM/yyyy 'lúc' HH:mm", { locale: vi }) : '—';

  const isReceivingStaff = user?.role === 'admin' || user?.role === 'receiving_staff';
  const isDepartmentStaff = user?.role === 'admin' || user?.role === 'department_staff';

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-center gap-4">
        <Link to="/admin/issues">
          <Button variant="ghost" size="icon"><ArrowLeft className="w-5 h-5" /></Button>
        </Link>
        <div className="flex-1">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-xl font-bold">{issue.tracking_code}</h1>
            <Badge className={si.color}>{si.label}</Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-1">{issue.title}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Issue content */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3 border-b">
              <CardTitle className="text-base flex items-center gap-2"><FileText className="w-4 h-4" /> Nội dung phản ánh</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <table className="w-full text-sm">
                <tbody>
                  <tr className="border-b">
                    <td className="px-4 py-3 text-muted-foreground font-medium w-40 bg-muted/30 align-top">Lĩnh vực</td>
                    <td className="px-4 py-3">{getCategoryLabel(issue.category)}</td>
                  </tr>
                  {issue.subcategory && (
                    <tr className="border-b">
                      <td className="px-4 py-3 text-muted-foreground font-medium bg-muted/30 align-top">Nhóm vấn đề</td>
                      <td className="px-4 py-3">{issue.subcategory}</td>
                    </tr>
                  )}
                  {issue.issue_address && (
                    <tr className="border-b">
                      <td className="px-4 py-3 text-muted-foreground font-medium bg-muted/30 align-top">Địa chỉ sự việc</td>
                      <td className="px-4 py-3">{issue.issue_address}</td>
                    </tr>
                  )}
                  {issue.maps_link && (
                    <tr className="border-b">
                      <td className="px-4 py-3 text-muted-foreground font-medium bg-muted/30 align-top">Google Maps</td>
                      <td className="px-4 py-3">
                        <a href={issue.maps_link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-primary hover:underline">
                          <ExternalLink className="w-3.5 h-3.5" /> Xem bản đồ
                        </a>
                      </td>
                    </tr>
                  )}
                  <tr className="border-b">
                    <td className="px-4 py-3 text-muted-foreground font-medium bg-muted/30 align-top">Nội dung</td>
                    <td className="px-4 py-3 whitespace-pre-wrap">{issue.description}</td>
                  </tr>
                  {issue.attachments?.length > 0 && (
                    <tr>
                      <td className="px-4 py-3 text-muted-foreground font-medium bg-muted/30 align-top">Tệp đính kèm</td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-2">
                          {issue.attachments.map((url, i) => (
                            <a key={i} href={url} target="_blank" rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 bg-muted px-3 py-1.5 rounded-md text-sm text-primary hover:bg-primary/10">
                              <Paperclip className="w-3.5 h-3.5" /> Tệp {i + 1}
                            </a>
                          ))}
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </CardContent>
          </Card>

          {/* Resolution */}
          {issue.resolution_note && (
            <Card className="border-0 shadow-sm border-l-4 border-l-green-500">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2 text-green-700"><CheckCircle className="w-4 h-4" /> Kết quả xử lý</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm whitespace-pre-wrap">{issue.resolution_note}</p>
                {issue.result_attachments?.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {issue.result_attachments.map((url, i) => (
                      <a key={i} href={url} target="_blank" rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 bg-green-50 px-3 py-1.5 rounded-md text-sm text-green-700 hover:bg-green-100">
                        <Paperclip className="w-3.5 h-3.5" /> Kết quả {i + 1}
                      </a>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar actions */}
        <div className="space-y-6">
          {/* Timeline */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2"><Clock className="w-4 h-4" /> Lịch sử</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-3">
              <div className="flex justify-between"><span className="text-muted-foreground">Ngày gửi</span><span>{formatDate(issue.created_date)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Tiếp nhận</span><span>{formatDate(issue.received_at)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Chuyển tiếp</span><span>{formatDate(issue.forwarded_at)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Hoàn thành</span><span>{formatDate(issue.resolved_at)}</span></div>
              {issue.assigned_department && (
                <div className="pt-2 border-t">
                  <p className="text-muted-foreground mb-1">Bộ phận xử lý</p>
                  <p className="font-medium">{DEPARTMENT_MAP[issue.assigned_department]}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Actions */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Thao tác</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Staff notes */}
              <div className="space-y-2">
                <Label className="text-sm">Ghi chú nội bộ</Label>
                <Textarea
                  rows={3}
                  placeholder="Ghi chú..."
                  value={note || issue.staff_notes || ''}
                  onChange={e => setNote(e.target.value)}
                />
                <Button size="sm" variant="outline" className="w-full" onClick={handleSaveNote} disabled={updateMutation.isPending}>
                  Lưu ghi chú
                </Button>
              </div>

              {/* Receiving staff actions */}
              {isReceivingStaff && issue.status === 'NEW' && (
                <Button className="w-full" onClick={handleReceive} disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <CheckCircle className="w-4 h-4 mr-2" />}
                  Tiếp nhận
                </Button>
              )}
              {isReceivingStaff && issue.status === 'RECEIVED' && (
                <Button className="w-full" onClick={handleForward} disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Forward className="w-4 h-4 mr-2" />}
                  Chuyển bộ phận xử lý
                </Button>
              )}

              {isDepartmentStaff && (issue.status === 'IN_PROGRESS' || issue.status === 'FORWARDED') && (
                <div className="space-y-2 pt-2 border-t">
                  <Label className="text-sm">Kết quả xử lý</Label>
                  <Textarea
                    rows={3}
                    placeholder="Nội dung kết quả..."
                    value={resolutionNote}
                    onChange={e => setResolutionNote(e.target.value)}
                  />
                  <div>
                    <input type="file" multiple onChange={handleResultFileUpload} className="hidden" id="result-upload" />
                    <label htmlFor="result-upload" className="inline-flex items-center gap-2 text-sm text-primary cursor-pointer hover:underline">
                      {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                      Đính kèm kết quả
                    </label>
                    {resultFiles.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {resultFiles.map((_, i) => (
                          <span key={i} className="text-xs bg-muted px-2 py-1 rounded flex items-center gap-1">
                            File {i + 1}
                            <button onClick={() => setResultFiles(prev => prev.filter((__, idx) => idx !== i))}>
                              <X className="w-3 h-3" />
                            </button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                  <Button className="w-full bg-green-600 hover:bg-green-700" onClick={handleResolve} disabled={updateMutation.isPending}>
                    {updateMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <CheckCircle className="w-4 h-4 mr-2" />}
                    Hoàn thành xử lý
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}