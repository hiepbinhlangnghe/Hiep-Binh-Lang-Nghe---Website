import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Search, Filter } from 'lucide-react';
import { Link, useOutletContext } from 'react-router-dom';
import { STATUS_MAP, CATEGORIES, DEPARTMENT_MAP } from '@/lib/constants';
import { format } from 'date-fns';
import { vi } from 'date-fns/locale';

export default function IssueList() {
  const { user } = useOutletContext();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const { data: issues = [], isLoading } = useQuery({
    queryKey: ['admin-issues-list'],
    queryFn: () => base44.entities.Issue.list('-created_date', 200)
  });

  // Filter by department for department_staff
  let filteredIssues = issues;
  if (user?.role === 'department_staff' && user?.department) {
    filteredIssues = filteredIssues.filter(i => i.assigned_department === user.department);
  }

  if (statusFilter !== 'all') {
    filteredIssues = filteredIssues.filter(i => i.status === statusFilter);
  }
  if (categoryFilter !== 'all') {
    filteredIssues = filteredIssues.filter(i => i.category === categoryFilter);
  }
  if (search.trim()) {
    const q = search.toLowerCase();
    filteredIssues = filteredIssues.filter(i =>
      i.tracking_code?.toLowerCase().includes(q) ||
      i.title?.toLowerCase().includes(q) ||
      i.full_name?.toLowerCase().includes(q)
    );
  }

  const getCategoryLabel = (val) => CATEGORIES.find(c => c.value === val)?.label || val;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Danh sách phản ánh</h1>
        <p className="text-muted-foreground text-sm mt-1">{filteredIssues.length} phản ánh</p>
      </div>

      {/* Filters */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Tìm theo mã hồ sơ, tiêu đề, tên..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-44">
                <SelectValue placeholder="Trạng thái" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả trạng thái</SelectItem>
                {Object.entries(STATUS_MAP).map(([key, val]) => (
                  <SelectItem key={key} value={key}>{val.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full sm:w-44">
                <SelectValue placeholder="Lĩnh vực" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả lĩnh vực</SelectItem>
                {CATEGORIES.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="border-0 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="text-left p-3 font-medium text-muted-foreground">Mã hồ sơ</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Tiêu đề</th>
                <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">Người gửi</th>
                <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Lĩnh vực</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Trạng thái</th>
                <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Bộ phận</th>
                <th className="text-left p-3 font-medium text-muted-foreground hidden sm:table-cell">Ngày gửi</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filteredIssues.map(issue => {
                const si = STATUS_MAP[issue.status] || STATUS_MAP.NEW;
                return (
                  <tr key={issue.id} className="hover:bg-muted/30 cursor-pointer" onClick={() => {}}>
                    <td className="p-3">
                      <Link to={`/admin/issues/${issue.id}`} className="text-primary font-medium hover:underline">
                        {issue.tracking_code}
                      </Link>
                    </td>
                    <td className="p-3">
                      <Link to={`/admin/issues/${issue.id}`} className="hover:text-primary block truncate max-w-[250px]">
                        {issue.title}
                      </Link>
                    </td>
                    <td className="p-3 hidden md:table-cell text-muted-foreground">{issue.full_name}</td>
                    <td className="p-3 hidden lg:table-cell text-muted-foreground">{getCategoryLabel(issue.category)}</td>
                    <td className="p-3">
                      <Badge variant="secondary" className={`${si.color} text-xs whitespace-nowrap`}>{si.label}</Badge>
                    </td>
                    <td className="p-3 hidden lg:table-cell text-muted-foreground text-xs">
                      {issue.assigned_department ? DEPARTMENT_MAP[issue.assigned_department] : '—'}
                    </td>
                    <td className="p-3 hidden sm:table-cell text-muted-foreground text-xs">
                      {format(new Date(issue.created_date), 'dd/MM/yyyy', { locale: vi })}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filteredIssues.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <Filter className="w-10 h-10 mx-auto mb-3 opacity-30" />
              <p>Không có phản ánh nào phù hợp</p>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}