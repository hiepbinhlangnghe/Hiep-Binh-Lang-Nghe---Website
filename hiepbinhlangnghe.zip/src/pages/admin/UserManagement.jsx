import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Shield } from 'lucide-react';
import { DEPARTMENT_MAP } from '@/lib/constants';

const ROLE_LABELS = {
  admin: 'Quản trị viên',
  receiving_staff: 'NV Tiếp nhận',
  department_staff: 'NV Bộ phận'
};

const ROLE_COLORS = {
  admin: 'bg-red-100 text-red-800',
  receiving_staff: 'bg-blue-100 text-blue-800',
  department_staff: 'bg-green-100 text-green-800'
};

export default function UserManagement() {
  const { data: users = [], isLoading } = useQuery({
    queryKey: ['admin-users'],
    queryFn: () => base44.entities.User.list()
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Quản lý nhân viên</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Để thêm nhân viên mới, mời họ qua chức năng "Invite User" trong cài đặt app.
        </p>
      </div>

      <Card className="border-0 shadow-sm">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-3 font-medium text-muted-foreground">Họ tên</th>
                  <th className="text-left p-3 font-medium text-muted-foreground">Email</th>
                  <th className="text-left p-3 font-medium text-muted-foreground">Vai trò</th>
                  <th className="text-left p-3 font-medium text-muted-foreground hidden sm:table-cell">Bộ phận</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-muted/30">
                    <td className="p-3 font-medium">{u.full_name || '—'}</td>
                    <td className="p-3 text-muted-foreground">{u.email}</td>
                    <td className="p-3">
                      <Badge variant="secondary" className={ROLE_COLORS[u.role] || 'bg-muted'}>
                        {ROLE_LABELS[u.role] || u.role}
                      </Badge>
                    </td>
                    <td className="p-3 hidden sm:table-cell text-muted-foreground">
                      {DEPARTMENT_MAP[u.department] || '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {users.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                <Users className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <p>Chưa có nhân viên nào</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}